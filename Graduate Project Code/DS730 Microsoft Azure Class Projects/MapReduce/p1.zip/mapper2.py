#!/usr/bin/python3.6

import sys

for line in sys.stdin:
    num_invoice = 0
    invoice_list = []
    stock_list1 = []
    stock_list_counter = 0
    invoice_list_num = 0
    list_values = 0
    strip_line = line.strip()
    split_list = strip_line.split("!")
    split_invoices = split_list[0].split(",")
    for invoice in split_invoices:
        num_invoice += 1
    split_stocks = split_list[1].split(":")
    stock_list1.append(split_stocks)
    invoice_list.append(num_invoice)
    num_invoice = 0
    length_invoice_list = len(invoice_list)
    while length_invoice_list > 0:
        current_stock = stock_list1[stock_list_counter]
        current_num_invoices = invoice_list[invoice_list_num]
        for value in current_stock:
            nocurrentvalue = [x for x in current_stock if x != value]
            for remaining_value in nocurrentvalue:
                current_num_invoices = invoice_list[invoice_list_num]
                while current_num_invoices > 0:
                    print(value + "\t" + remaining_value)
                    current_num_invoices -= 1
        stock_list_counter += 1
        invoice_list_num += 1
        length_invoice_list -= 1
        
