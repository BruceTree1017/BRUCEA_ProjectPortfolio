#!/usr/bin/python3.6

import sys

counter = 0
max_amount = 0 
idMax = ""
current_date_country = ""


for line in sys.stdin:
    counter += 1
    datecountry, customerID, amount = line.split("\t", 2)
    amount = float(amount)
    if current_date_country == "":
        current_date_country = datecountry
        idMax = customerID
        max_amount = amount
    elif (current_date_country == datecountry):
        if(max_amount < amount):
            max_amount = amount
            idMax = customerID
    else:
        print(current_date_country + " : " + idMax)
        current_date_country = datecountry
        max_amount = amount
        idMax = customerID

if current_date_country == datecountry:
    print(current_date_country + " : " + idMax)