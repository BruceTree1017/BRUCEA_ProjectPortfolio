#!/usr/bin/python3.6

import sys


original_value_dict = {}
final_value_dict = {}
previous_key = 0
sorted_counter = 1
final_pairing = ""


for line in sys.stdin:
    line = line.strip()
    stockcode, recommended_pairing = line.split("\t", 1)
    if previous_key == 0:
        previous_key = stockcode
        original_value_dict[recommended_pairing] = 1
    elif previous_key == stockcode:
        if recommended_pairing in original_value_dict:
            original_value_dict[recommended_pairing] += 1
        else:
            original_value_dict[recommended_pairing] = 1 
    else: 
        final_pairing = final_pairing + previous_key + " : "
        for key in original_value_dict:
            if original_value_dict[key] >= 5:
                final_value_dict[key] = "Yes"
        if(len(final_value_dict) == 0):
            original_value_dict = {}
            final_value_dict = {}
            sorted_dict = {}
            final_pairing = ""
            previous_key = stockcode
            original_value_dict[recommended_pairing] = 1
        else:
            sorted_dict = dict(sorted(final_value_dict.items()))
            length_sorted = len(sorted_dict)
            for key in sorted_dict:
                if sorted_counter < length_sorted:
                    final_pairing = final_pairing + key + ","
                    sorted_counter += 1
                else: 
                    final_pairing = final_pairing + key
            print(final_pairing)
            original_value_dict = {}
            final_value_dict = {}
            sorted_dict = {}
            final_pairing = ""
            sorted_counter = 1
            previous_key = stockcode
            original_value_dict[recommended_pairing] = 1
        
        
    
if(previous_key == stockcode):
    final_pairing = final_pairing + previous_key + " : "
    for key in original_value_dict:
        if original_value_dict[key] >= 5:
            final_value_dict[key] = "Yes"
    if(len(final_value_dict) != 0):
        sorted_dict = dict(sorted(final_value_dict.items()))
        length_sorted = len(sorted_dict)
        for key in sorted_dict:
            if sorted_counter < length_sorted:
                final_pairing = final_pairing + key + ","
                sorted_counter += 1
            else: 
                final_pairing = final_pairing + key
        print(final_pairing)