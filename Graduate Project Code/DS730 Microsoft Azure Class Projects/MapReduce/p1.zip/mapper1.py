#!/usr/bin/python3.6

import sys

for line in sys.stdin:
    line_strip = line.strip()
    spender_split = line_strip.split(",")
    
    # Address Case Where A Mapper Encounters Header
    if(spender_split[0] == "InvoiceNo"):
        continue
    
    # Address Rows With Returns
    elif(spender_split[0].startswith("C")):
        continue 
    
    # Address Missing Customer ID's
    elif(spender_split[6] == ""):
        continue
    
    else:
        Total_Spent = round(float(spender_split[3]) * float(spender_split[5]), 2)
        CustomerID = spender_split[6]
        Country = spender_split[7]
        Date = spender_split[4]
        Split_Date = Date.split("/")
        Month = Split_Date[0]
        if (int(Month) < 10):
            Month = "0" + Month
        Month_Country = Month + "," + Country
        print(Month_Country+"\t"+CustomerID+"\t"+str(Total_Spent))
        
        
    
    
    
    

        
    
    


