import java.io.*;
import java.util.*;
import java.nio.file.Files;
import java.nio.file.Path;



public class GlobalRunner {

    public static Map<String, Stack<String>> GlobalMap = new TreeMap<String, Stack<String>>();
    public static Integer ThreadNumber = 0;

    public synchronized static void AddMap(Map<String, String> ThreadTree_Mapper){
        // Add one to the Thread Counter! 
        ThreadNumber ++;
        // Address the case where we hit the next thread and some values from the first map did not occur in the next thread
        String NoOccurance = " ";

        // Loop through the key/values and add the Word to the GlobalMap if first thread!
        for (String key : ThreadTree_Mapper.keySet()) { 
            // If this is the FIRST Thread to map, then proceed normally
            if(ThreadNumber == 1){
                // Get Pages for each key
                String pages = ThreadTree_Mapper.get(key); 
                // Now add the key with pages to the Global map
                // Check if the key is in the Global map already
                if(GlobalMap.containsKey(key)){
                    // If the word is in the Globalmap, simply add the page numbers to the stack !
                    GlobalMap.get(key).add(pages);
                }else{
                    // If the word is not in the GlobalMap, first add it with the pages
                    GlobalMap.put(key,new Stack<String>());
                    // Then add the page number for the word if not already there
                    GlobalMap.get(key).add(pages);
                }
            }
        } 

        // Now, Take the GlobalMap, and check if the Keys occur at all in the next N Threads maps. If they do not, Add a NoOccurrance
        // If they do, add the page numbers to the stack
        if(ThreadNumber > 1){
            for(String key : GlobalMap.keySet()){
                if(ThreadNumber > 1){
                    if(ThreadTree_Mapper.containsKey(key)){
                        // If the word is in the CurrentThread Map, simply add the page numbers to the Global stack !
                        String CurrentThread_pages = ThreadTree_Mapper.get(key);
                        GlobalMap.get(key).add(" " + CurrentThread_pages);
                    } else{
                        // If the Key is not in the current thread, then add a blank occurance for that key in the Global Map!
                        GlobalMap.get(key).add(NoOccurance);
                    }
                }
            }
        }

        // Now, if a currentThread Key is not in the Global Thread, we need to add N-1 No Occurences before the page number 
        if(ThreadNumber > 1){
            for(String key : ThreadTree_Mapper.keySet()){
                String Thread_pages = ThreadTree_Mapper.get(key);
                // If the Global Map already contains the currentThread key, we have addressed this case already, so we just continue
                if(GlobalMap.containsKey(key)){
                    continue;
                } else{
                    // Since the word is brand new to the Global Map, we need to add N-1 No Occurences before we add its page numbers!
                    // First Add the CurrentThread key to the Global Map
                    GlobalMap.put(key,new Stack<String>());
                    for(int i = 1; i < ThreadNumber; i++){
                        // Now add the No Occurences needed
                        GlobalMap.get(key).add(NoOccurance);
                    }
                    //Finally, add the page numbers to the stack for the new key
                    GlobalMap.get(key).add(" " + Thread_pages);
                }
            }
        }
    }



    public static void main(String args[])throws Exception{
        //Start timing here.
		long start = System.currentTimeMillis();

        // Define Output Folder for writer Use
        String output_folder = args[1];
        String basePath_output = new File(output_folder).getAbsolutePath();

        // Define Number of Chars per Page for Thread Use
        Integer chars_page = Integer.parseInt(args[2]);
        
        // Extract input folder with files
        String userInput_folder = args[0];
        String basePath_input = new File(userInput_folder).getAbsolutePath();
        File files = new File(basePath_input);
        File[] listOfFiles = files.listFiles();

        // Define Number of Threads Counter for Input Files!
        Integer numThreads = 0;

        // For Loop to count number of files and increase numThreads by one for each file
        for (File Readfiles : listOfFiles){
            numThreads += 1;
        }

        // Now Create A Worker Thread for Each File!
        GlobalIndex[] theWorkers = new GlobalIndex[numThreads];

        // Now For Loop for each file to be assigned to a worker thread!
        for(int i = 0; i < numThreads; i++){
            File workerFile = listOfFiles[i];
            theWorkers[i] = new GlobalIndex(workerFile, chars_page);
            theWorkers[i].start();
        }

        // Wait for each worker to finish before sending next file values to global and then writing to file!
        for(GlobalIndex worker : theWorkers){
            if(worker.isAlive()){
                worker.join();
            }
        }

        // Define File output and place to write it to!
        // Once All Words have been accounted for and mapped (Workers are done), Create file to write output to
        File myObj = new File(basePath_output + "/" + "output.txt");

        // Create Writer Object for output file!
        FileWriter myWriter = new FileWriter(myObj);
        
        // Now, Make sure to write Word header first!
        for (String key : GlobalMap.keySet()) { 
            if(key.equals("Word, ")){
                Stack<String> WordHeader = GlobalMap.get(key); 
                // Get values of Pages as string comma seperated
                List<String> titleString = new ArrayList<>();
                for (String i : WordHeader) {
                    titleString.add(i);
                } 
                String result = String.join(", ", titleString);
                myWriter.write(key + result + "\n");
            }
        } 

        // Finally, Add All other Key/Page Pairs to output file
        for (String key : GlobalMap.keySet()) { 
            if(key.equals("Word, ")){
                continue;
            } else{
                Stack<String> pages = GlobalMap.get(key); 
                // Get values of Pages as string comma seperated
                List<String> intString = new ArrayList<>();
                for (String i : pages) {
                    intString.add(i);
                } 
                String result = String.join(",", intString);
                myWriter.write(key + result + "\n");
            }
        } 
        

        // Finally, Print out how long it took.
        long end = System.currentTimeMillis();
        System.out.println("Time taken: "+(end-start));
    }
}
