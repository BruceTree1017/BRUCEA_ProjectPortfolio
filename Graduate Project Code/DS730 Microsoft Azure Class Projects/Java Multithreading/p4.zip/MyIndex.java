import java.io.*;
import java.util.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class MyIndex extends Thread{
    private String output_folderpath;
    private File thread_file;
    private Integer chars_page;

    public MyIndex(String output_folderpath, File thread_file, Integer chars_page){
        this.chars_page = chars_page;
        this.output_folderpath = output_folderpath;
        this.thread_file = thread_file;
    }

    public void run(){
        try {
            // Define Output Folder for Later Use
            String output_folder = output_folderpath;
            String basePath_output = new File(output_folderpath).getAbsolutePath();
            // Set Page Marker and Char Counter
            Integer page_num = 1;
            Integer char_count = 0;
            // Set Characters Per Page Marker
            Integer threadchars_page = chars_page;
            // Define Storage Map
            Map<String, TreeSet<Integer>> tree_map = new TreeMap<String, TreeSet<Integer>>();
            if (thread_file.isFile()) {
                    // Extract name of file without .txt extension
                    String filename = thread_file.getAbsolutePath().substring(thread_file.getAbsolutePath().lastIndexOf("/")+1);
                    String currentFile = filename.replace(".txt", "");
                    // Create File Reader with Scanner
                    Scanner sc = new Scanner(thread_file);
                    while(sc.hasNext()){
                        // Read every line!
                        String s = sc.next();
                        int chars_s = s.length();
                        // Add to Char Count for Page! 
                        char_count += chars_s;
                        // Now Check if chars_page is less than specified # of chars allowed per page!
                        if(char_count <= chars_page){
                            // convert s to lowercase for case insensitivity
                            String Lowers = s.toLowerCase();
                            // Now Check if s is in the Hashmap
                            if(tree_map.containsKey(Lowers)){
                                // If the word is in the Hashmap, simply add the page number if the page is not already there! 
                                tree_map.get(Lowers).add(page_num);
                            }else{
                                // If the word is not in the Hashmap, first add it with an integer array to store the page numbers!
                                tree_map.put(Lowers, new TreeSet<Integer>());
                                // Then add the page number for the word
                                tree_map.get(Lowers).add(page_num);
                            }
                        }else{
                            // IF Char count has exceeded number allowed per page, increase the page number and reset the char count!
                            page_num += 1;
                            char_count = 0;
                            // Then address the String at hand before going to top of while loop
                            // Add to Char Count for Page! 
                            char_count += chars_s;
                            // convert s to lowercase for case insensitivity
                            String Lower2 = s.toLowerCase();
                            // Now Check if s is in the Hashmap
                            if(tree_map.containsKey(Lower2)){
                                // If the word is in the Hashmap, simply add the page number if the page is not already there! 
                                tree_map.get(Lower2).add(page_num);
                            }else{
                                // If the word is not in the Hashmap, first add it with an integer array to store the page numbers!
                                tree_map.put(Lower2, new TreeSet<Integer>());
                                // Then add the page number for the word if not already there
                                tree_map.get(Lower2).add(page_num);
                            }
                        }
                    }
                    // Once All Words have been accounted for and mapped, Create file to write output to
                    File myObj = new File(basePath_output + "/" + currentFile + "_output.txt");
                    // Create a writer object to write to output file the words and pages in format.
                    FileWriter myWriter = new FileWriter(myObj);
                    for (String key : tree_map.keySet()) { 
                        // Get Pages for each key
                        TreeSet<Integer> pages = tree_map.get(key); 
                        // Get values of Pages as string comma seperated
                        List<String> intString = new ArrayList<>();
                        for (Integer i : pages) {
                            intString.add(String.valueOf(i));
                        } 
                        String result = String.join(", ", intString);
                        // Finally, Write output to myobj file created above
                        myWriter.write(key + " " + result + "\n");
                    } 
                    // Finally, Close the writer
                    myWriter.close();
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }
}
