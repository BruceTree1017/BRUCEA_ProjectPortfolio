import java.io.*;
import java.util.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class Index {
    public static void main(String args[])throws Exception{
        
        //Start timing here.
		long start = System.currentTimeMillis();

        // Define Output Folder for Later Use
        String output_folder = args[1];
        String basePath_output = new File(output_folder).getAbsolutePath();
        
        // Extract input folder with files
        String userInput_folder = args[0];
        String basePath_input = new File(userInput_folder).getAbsolutePath();
        File files = new File(basePath_input);
        File[] listOfFiles = files.listFiles();

        // Loop Through files one at a time!
        for (File Readfiles : listOfFiles) {
            // Set Page Marker and Char Counter
            Integer page_num = 1;
            Integer char_count = 0;
            // Set Characters Per Page Marker
            Integer chars_page = Integer.parseInt(args[2]);
            // Define Storage Map
            Map<String, TreeSet<Integer>> tree_map = new TreeMap<String, TreeSet<Integer>>();
            if (Readfiles.isFile()) {
                    // Extract name of file without .txt extension
                    String filename = Readfiles.getAbsolutePath().substring(Readfiles.getAbsolutePath().lastIndexOf("/")+1);
                    String currentFile = filename.replace(".txt", "");
                    // Create File Reader with Scanner
                    Scanner sc = new Scanner(Readfiles);
                    while(sc.hasNext()){
                        // Read every line!
                        String s = sc.next();
                        int chars_s = s.length();
                        // Add to Char Count for Page! 
                        char_count += chars_s;
                        // Now Check if chars_page is less than specified # of chars allowed per page!
                        if(char_count <= chars_page){
                            // convert s to lowercase for case insensitivity
                            String Lowers = s.toLowerCase();
                            // Now Check if s is in the Hashmap
                            if(tree_map.containsKey(Lowers)){
                                // If the word is in the Hashmap, simply add the page number if the page is not already there! 
                                tree_map.get(Lowers).add(page_num);
                            }else{
                                // If the word is not in the Hashmap, first add it with an integer array to store the page numbers!
                                tree_map.put(Lowers, new TreeSet<Integer>());
                                // Then add the page number for the word
                                tree_map.get(Lowers).add(page_num);
                            }
                        }else{
                            // IF Char count has exceeded number allowed per page, increase the page number and reset the char count!
                            page_num += 1;
                            char_count = 0;
                            // Then address the String at hand before going to top of while loop
                            // Add to Char Count for Page! 
                            char_count += chars_s;
                            // convert s to lowercase for case insensitivity
                            String Lower2 = s.toLowerCase();
                            // Now Check if s is in the Hashmap
                            if(tree_map.containsKey(Lower2)){
                                // If the word is in the Hashmap, simply add the page number if the page is not already there! 
                                tree_map.get(Lower2).add(page_num);
                            }else{
                                // If the word is not in the Hashmap, first add it with an integer array to store the page numbers!
                                tree_map.put(Lower2, new TreeSet<Integer>());
                                // Then add the page number for the word if not already there
                                tree_map.get(Lower2).add(page_num);
                            }
                        }
                    }
                    // Once All Words have been accounted for and mapped, Create file to write output to
                    File myObj = new File(basePath_output + "/" + currentFile + "_output.txt");
                    // Create a writer object to write to output file the words and pages in format.
                    FileWriter myWriter = new FileWriter(myObj);
                    for (String key : tree_map.keySet()) { 
                        // Get Pages for each key
                        TreeSet<Integer> pages = tree_map.get(key); 
                        // Get values of Pages as string comma seperated
                        List<String> intString = new ArrayList<>();
                        for (Integer i : pages) {
                            intString.add(String.valueOf(i));
                        } 
                        String result = String.join(", ", intString);
                        // Finally, Write output to myobj file created above
                        myWriter.write(key + " " + result + "\n");
                    } 
                    // Finally, Close the writer
                    myWriter.close();
            }
        }

    // Print out how long it took.
	long end = System.currentTimeMillis();
	System.out.println("Time taken: "+(end-start));
    }
}