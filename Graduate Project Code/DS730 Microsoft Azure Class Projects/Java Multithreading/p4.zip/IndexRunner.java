import java.io.*;
import java.util.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class IndexRunner {
    
    public static void main(String args[])throws Exception{
        //Start timing here.
		long start = System.currentTimeMillis();

        // Define Output Folder for Thread Use
        String output_folder = args[1];

        // Define Number of Chars per Page for Thread Use
        Integer chars_page = Integer.parseInt(args[2]);
        
        // Extract input folder with files
        String userInput_folder = args[0];
        String basePath_input = new File(userInput_folder).getAbsolutePath();
        File files = new File(basePath_input);
        File[] listOfFiles = files.listFiles();

        // Define Number of Threads Counter for Input Files!
        Integer numThreads = 0;

        // For Loop to count number of files and increase numThreads by one for each file
        for (File Readfiles : listOfFiles){
            numThreads += 1;
        }

        // Now Create A Worker Thread for Each File!
        MyIndex[] theWorkers = new MyIndex[numThreads];

        // Now For Loop for each file to be assigned to a worker thread!
        for(int i = 0; i < numThreads; i++){
            File workerFile = listOfFiles[i];
            theWorkers[i] = new MyIndex(output_folder, workerFile, chars_page);
            theWorkers[i].start();
        }
        // Finally, Print out how long it took.
        long end = System.currentTimeMillis();
        System.out.println("Time taken: "+(end-start));
    }
}
